// src/components/Header.tsx
'use client';

import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Search, User, Heart, ShoppingBag, Menu, X, Plus, Minus } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { useAuth } from '@/context/AuthContext';
import { useWishlist } from '@/context/WishlistContext';
import styles from '@/styles/Header.module.css';
import { NavigationLink } from '@/types/navigation';
import { getNavigationLinks, searchProducts } from '@/lib/api';
import { Product } from '@/lib/types';

interface StrapiCategory { id: number; name: string; slug: string; }

const MOCK_NAV_DATA: NavigationLink[] = [
  { id: 1, label: 'Магазин', href: '/shop', mega_menu: null },
  { id: 2, label: 'Категории', href: '/categories', mega_menu: { id: 1, columns: [], image: { url: 'https://placehold.co/300x200/D3C5C0/333?text=New+Arrivals', alt: 'New Arrivals' }, image_title: 'DISCOVER NEW ARRIVALS', image_href: '/shop/new' }},
  { id: 3, label: 'Контакти', href: '/contact-us', mega_menu: null },
  { id: 4, label: 'Уроци', href: 'https://tatyanagyumisheva.com', mega_menu: null },
];

const Header = () => {
  const [navLinks, setNavLinks] = useState<NavigationLink[]>(MOCK_NAV_DATA);
  const { toggleCart, cartCount } = useCart();
  const { user } = useAuth();
  const { wishlistCount } = useWishlist();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [openAccordion, setOpenAccordion] = useState<number | null>(null);
  const [isScrolled, setIsScrolled] = useState(false);
  const [dynamicCategories, setDynamicCategories] = useState<StrapiCategory[]>([]);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Search State
  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [results, setResults] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isResultsVisible, setIsResultsVisible] = useState(false);
  const [mobileQuery, setMobileQuery] = useState('');
  const [mobileDebouncedQuery, setMobileDebouncedQuery] = useState('');
  const [mobileResults, setMobileResults] = useState<Product[]>([]);
  const [isMobileLoading, setIsMobileLoading] = useState(false);

  useEffect(() => {
    const handler = setTimeout(() => setDebouncedQuery(query), 300);
    return () => clearTimeout(handler);
  }, [query]);

  useEffect(() => {
    const handler = setTimeout(() => setMobileDebouncedQuery(mobileQuery), 300);
    return () => clearTimeout(handler);
  }, [mobileQuery]);

  useEffect(() => {
    if (debouncedQuery.length > 1) {
      setIsLoading(true);
      setIsResultsVisible(true);
      searchProducts(debouncedQuery).then(data => {
        setResults(data);
        setIsLoading(false);
      });
    } else {
      setResults([]);
      setIsResultsVisible(false);
    }
  }, [debouncedQuery]);

  useEffect(() => {
    if (mobileDebouncedQuery.length > 1) {
      setIsMobileLoading(true);
      searchProducts(mobileDebouncedQuery).then(data => {
        setMobileResults(data);
        setIsMobileLoading(false);
      });
    } else {
      setMobileResults([]);
    }
  }, [mobileDebouncedQuery]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
        setIsResultsVisible(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const closeDesktopSearch = () => { setQuery(''); setIsResultsVisible(false); };
  const closeMobileMenu = () => { setIsMobileMenuOpen(false); setMobileQuery(''); };
  const handleAccordionToggle = (id: number) => { setOpenAccordion(openAccordion === id ? null : id); };

  useEffect(() => {
    const fetchNavData = async () => {
      const categories: StrapiCategory[] = await getNavigationLinks();
      if (categories) { setDynamicCategories(categories); }
    };
    fetchNavData();
    const handleScroll = () => { setIsScrolled(window.scrollY > 10); };
    window.addEventListener('scroll', handleScroll);
    return () => { window.removeEventListener('scroll', handleScroll); };
  }, []);

  return (
    <>
      <header ref={searchContainerRef} className={`${styles.header} ${isScrolled ? styles.scrolled : ''}`}>
        <div className={styles.topBar}>
          <div className={styles.leftSection}>
            <button onClick={() => setIsMobileMenuOpen(true)} className={`${styles.iconButton} ${styles.mobileOnly}`}><Menu size={24} /></button>
            <Link href="/wishlist" className={`${styles.iconButton} ${styles.mobileOnly}`} style={{ position: 'relative' }}>
                <Heart size={18} />
                {wishlistCount > 0 && ( <span className={styles.countBadge}>{wishlistCount}</span> )}
            </Link>
            <div className={`${styles.inlineSearchContainer} ${styles.desktopOnly}`}>
              <Search size={18} className={styles.inlineSearchIcon} />
              <input type="text" placeholder="Търсене..." className={styles.inlineSearchInput} value={query} onChange={(e) => setQuery(e.target.value)} onFocus={() => { if (query.length > 1) setIsResultsVisible(true); }} />
            </div>
          </div>
          
          {/* --- DESKTOP LOGO FIXED --- */}
          <div className={styles.logoSection}>
            <Link href="https://www.mydreambeauty.net" className={styles.logoLinkWrapper}>
              {/* Using standard img tag for absolute control over sizing in this specific layout context, 
                  or Next Image with specific styling to ensure it fills the container */}
              <img 
                src="/logo.jpg" 
                alt="My Dream by Tatyana Gyumisheva" 
                className={styles.logoImage}
              />
            </Link>
          </div>
          {/* -------------------------- */}

          <div className={styles.rightSection}>
            <Link href={user ? "/account" : "/login"} className={styles.iconButton}><User size={18} /></Link>
            <Link href="/wishlist" className={`${styles.iconButton} ${styles.desktopOnly}`} style={{ position: 'relative' }}><Heart size={18} />{wishlistCount > 0 && ( <span className={styles.countBadge}>{wishlistCount}</span> )}</Link>
            <button onClick={toggleCart} className={styles.iconButton} style={{ position: 'relative' }}><ShoppingBag size={18} />{cartCount > 0 && ( <span className={styles.countBadge}>{cartCount}</span> )}</button>
          </div>
        </div>
        <nav className={styles.navBar}>{navLinks.map((link) => (<div key={link.id} className={styles.navItem}><Link href={link.href} className={styles.navLink}>{link.label}</Link>{link.mega_menu && (<div className={styles.megaMenu}><div className={styles.megaMenuContent}><div className={styles.megaMenuColumns}><div className={styles.megaMenuColumn}>{dynamicCategories.map((category) => ( category && category.slug && ( <Link key={category.id} href={`/categories/${category.slug}`}>{category.name}</Link> ))) }</div></div><div className={styles.megaMenuImage}><Link href={link.mega_menu.image_href}><img src={link.mega_menu.image.url} alt={link.mega_menu.image.alt} /><p>{link.mega_menu.image_title}</p></Link></div></div></div>)}</div>))}</nav>
        {isResultsVisible && (<div className={styles.resultsPanel}>{isLoading && <div className={styles.resultsMessage}>Searching...</div>}{!isLoading && results.length === 0 && debouncedQuery.length > 1 && (<div className={styles.resultsMessage}>No products found for &quot;{debouncedQuery}&quot;.</div>)}{results.length > 0 && (<ul className={styles.resultsList}>{results.slice(0, 5).map((product) => (<li key={product.id}><Link href={`/products/${product.slug}`} onClick={closeDesktopSearch} className={styles.resultItem}><div className={styles.resultImage}><Image src={product.images[0]?.url || '/placeholder.jpg'} alt={product.name} fill style={{ objectFit: 'cover' }} /></div><span className={styles.resultName}>{product.name}</span></Link></li>))}</ul>)}</div>)}
      </header>

      <div className={`${styles.mobileNavDrawer} ${isMobileMenuOpen ? styles.open : ''}`}>
        <div className={styles.drawerHeader}>
          <button onClick={closeMobileMenu} className={styles.iconButton}><X size={24} /></button>
          
          {/* --- MOBILE LOGO FIXED --- */}
          <div className={styles.drawerLogoWrapper}>
            <Link href="https://www.mydreambeauty.net" onClick={closeMobileMenu}>
             <Image 
              src="/logo.jpg" 
              alt="My Dream" 
              width={180}
              height={60}
              style={{ objectFit: 'contain', mixBlendMode: 'multiply' }}
            />
            </Link>
          </div>
          {/* ------------------------- */}

        </div>
        <div className={styles.drawerSearchWrapper}>
          <input type="text" placeholder="Search For..." className={styles.drawerSearchInput} value={mobileQuery} onChange={(e) => setMobileQuery(e.target.value)} />
          <Search size={20} className={styles.drawerSearchIcon} />
        </div>
        <div className={styles.drawerContent}>
          {mobileQuery.length > 1 ? (
            <div className={styles.drawerResultsContainer}>
              {isMobileLoading && <div className={styles.drawerResultsMessage}>Searching...</div>}
              {!isMobileLoading && mobileResults.length === 0 && (<div className={styles.drawerResultsMessage}>No products found.</div>)}
              {mobileResults.length > 0 && (<ul className={styles.drawerResultsList}>{mobileResults.map(product => (<li key={product.id}><Link href={`/products/${product.slug}`} className={styles.drawerResultItem} onClick={closeMobileMenu}><div className={styles.drawerResultImage}><Image src={product.images[0]?.url || '/placeholder.jpg'} alt={product.name} fill style={{ objectFit: 'cover' }} /></div><span className={styles.drawerResultName}>{product.name}</span></Link></li>))}</ul>)}
            </div>
          ) : (
            <nav className={styles.drawerNav}>{navLinks.map((link) => (<div key={link.id} className={styles.accordionItem}>{link.label === 'Категории' ? (<><div className={styles.accordionHeader} onClick={() => handleAccordionToggle(link.id)}><span>{link.label}</span>{openAccordion === link.id ? <Minus size={20} /> : <Plus size={20} />}</div><div className={`${styles.accordionContent} ${openAccordion === link.id ? styles.open : ''}`}>{dynamicCategories.map(subLink => ( subLink && subLink.slug && ( <Link key={subLink.id} href={`/categories/${subLink.slug}`} className={styles.accordionLink} onClick={closeMobileMenu}>{subLink.name}</Link> ))) }</div></>) : ( <div className={styles.accordionHeader}><Link href={link.href} onClick={closeMobileMenu}>{link.label}</Link></div> )}</div>))}</nav>
          )}
        </div>
      </div>
      <div className={`${styles.overlay} ${isMobileMenuOpen ? styles.open : ''}`} onClick={closeMobileMenu} />
    </>
  );
};

export default Header;
